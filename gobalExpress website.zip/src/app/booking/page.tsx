"use client";

import { useState } from "react";
import AddressForm from "../../components/AddressForm";
import PackageDetailsForm from "../../components/PackageDetailsForm";

export interface Address {
  forename: string;
  surname: string;
  email: string;
  phone: string;
  companyName?: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  countryState: string;
  postcode: string;
  country: string;
}

export interface PackageItem {
  description: string;
  commodityCode: string;
  countryOfOrigin: string;
  quantity: number;
  valuePerItem: number;
  weightPerItem: number;
  length: number;
  width: number;
  height: number;
}

interface ServiceQuote {
  ServiceID: number;
  ServiceName: string;
  CarrierName: string;
  ChargeableWeight: number;
  TransitTimeEstimate: string;
  SameDayCollectionCutOffTime: string;
  IsWarehouseService: boolean;
  TotalCost: {
    TotalCostGrossWithCollection: number;
  };
  ServicePriceBreakdown: Array<{
    Code: string;
    Description: string;
    Cost: number;
  }>;
  OptionalExtras: Array<{
    Code: string;
    Description: string;
    Cost: number;
  }>;
  SignatureRequiredAvailable: boolean;
  ServiceType: string;
}

export default function BookingPage() {
  const [step, setStep] = useState(1);
  const [collectionAddress, setCollectionAddress] = useState<Address | null>(
    null
  );
  const [deliveryAddress, setDeliveryAddress] = useState<Address | null>(null);
  const [packageItems, setPackageItems] = useState<PackageItem[]>([]);
  const [reasonForShipment, setReasonForShipment] = useState<string>("");
  const [collectionDate, setCollectionDate] = useState<string>("");
  const [readyFrom, setReadyFrom] = useState<string>("");
  const [quotes, setQuotes] = useState<ServiceQuote[]>([]);
  const [selectedService, setSelectedService] = useState<ServiceQuote | null>(
    null
  );
  const [quoteId, setQuoteId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAddressSubmit = (collection: Address, delivery: Address) => {
    setCollectionAddress(collection);
    setDeliveryAddress(delivery);
    setStep(2);
  };

  const handlePackageDetailsSubmit = (
    items: PackageItem[],
    reason: string,
    date: string,
    time: string
  ) => {
    setPackageItems(items);
    setReasonForShipment(reason);
    setCollectionDate(date);
    setReadyFrom(time);
    fetchQuotes(collectionAddress!, deliveryAddress!, items, reason);
  };

  const fetchQuotes = async (
    collection: Address,
    delivery: Address,
    items: PackageItem[],
    reason: string
  ) => {
    try {
      const response = await fetch("/api/getQuote", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          collectionAddress: collection,
          deliveryAddress: delivery,
          packageItems: items,
          reasonForShipment: reason,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(data.response, "application/xml");
        const quoteIdElement =
          xmlDoc.getElementsByTagName("QuoteID")[0]?.textContent;
        const serviceResults =
          xmlDoc.getElementsByTagName("ServiceQuoteResult");

        const quotesList: ServiceQuote[] = Array.from(serviceResults).map(
          (result) => {
            const getText = (tag: string) =>
              result.getElementsByTagName(tag)[0]?.textContent || "";
            const totalCost = result.getElementsByTagName("TotalCost")[0];
            const priceBreakdown = Array.from(
              result
                .getElementsByTagName("ServicePriceBreakdown")[0]
                ?.getElementsByTagName("PriceElement") || []
            ).map((elem) => ({
              Code: getText.call(elem, "Code"),
              Description: getText.call(elem, "Description"),
              Cost: parseFloat(getText.call(elem, "Cost")),
            }));
            const optionalExtras = Array.from(
              result
                .getElementsByTagName("OptionalExtras")[0]
                ?.getElementsByTagName("PriceElement") || []
            ).map((elem) => ({
              Code: getText.call(elem, "Code"),
              Description: getText.call(elem, "Description"),
              Cost: parseFloat(getText.call(elem, "Cost")),
            }));

            return {
              ServiceID: parseInt(getText("ServiceID")),
              ServiceName: getText("ServiceName"),
              CarrierName: getText("CarrierName"),
              ChargeableWeight: parseFloat(getText("ChargeableWeight")),
              TransitTimeEstimate: getText("TransitTimeEstimate"),
              SameDayCollectionCutOffTime: getText(
                "SameDayCollectionCutOffTime"
              ),
              IsWarehouseService: getText("IsWarehouseService") === "true",
              TotalCost: {
                TotalCostGrossWithCollection: parseFloat(
                  totalCost?.getElementsByTagName(
                    "TotalCostGrossWithCollection"
                  )[0]?.textContent || "0"
                ),
              },
              ServicePriceBreakdown: priceBreakdown,
              OptionalExtras: optionalExtras,
              SignatureRequiredAvailable:
                getText("SignatureRequiredAvailable") === "true",
              ServiceType: getText("ServiceType"),
            };
          }
        );

        setQuoteId(parseInt(quoteIdElement || "0"));
        setQuotes(quotesList);
        setStep(3);
      } else {
        setError(data.error || "Failed to fetch quotes");
      }
    } catch (err: any) {
      setError("Error fetching quotes: " + err.message);
    }
  };

  const handleServiceSelect = (service: ServiceQuote) => {
    setSelectedService(service);
    handleBookShipment();
  };

  const handleBookShipment = async () => {
    if (!quoteId || !selectedService) return;

    try {
      const response = await fetch("/api/book-shipping", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          quoteId,
          selectedServiceId: selectedService.ServiceID,
          collectionDate,
          readyFrom,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        setStep(4);
      } else {
        setError(data.error || "Failed to book shipment");
      }
    } catch (err: any) {
      setError("Error booking shipment: " + err.message);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6 text-gray-800">Book a Shipment</h1>

      {error && (
        <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-md">
          {error}
        </div>
      )}

      {step === 1 && <AddressForm onSubmit={handleAddressSubmit} />}

      {step === 2 && (
        <PackageDetailsForm
          onSubmit={handlePackageDetailsSubmit}
          onBack={() => setStep(1)}
        />
      )}

      {step === 3 && (
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-gray-800">
            Available Services
          </h2>
          {quotes.length > 0 ? (
            <div className="space-y-4">
              {quotes.map((quote) => (
                <div
                  key={quote.ServiceID}
                  className="p-6 bg-white rounded-lg shadow-md border border-gray-200"
                >
                  <h3 className="text-xl font-bold text-gray-800 mb-2">
                    {quote.ServiceName}
                  </h3>
                  <p className="text-gray-600 mb-1">
                    <span className="font-semibold">Carrier:</span>{" "}
                    {quote.CarrierName}
                  </p>
                  <p className="text-gray-600 mb-1">
                    <span className="font-semibold">Service Type:</span>{" "}
                    {quote.ServiceType}
                  </p>
                  <p className="text-gray-600 mb-1">
                    <span className="font-semibold">Transit Time:</span>{" "}
                    {quote.TransitTimeEstimate} days
                  </p>
                  <p className="text-gray-600 mb-1">
                    <span className="font-semibold">Chargeable Weight:</span>{" "}
                    {quote.ChargeableWeight} kg
                  </p>
                  <p className="text-gray-600 mb-1">
                    <span className="font-semibold">
                      Same Day Collection Cut-Off:
                    </span>{" "}
                    {quote.SameDayCollectionCutOffTime}
                  </p>
                  <p className="text-gray-600 mb-1">
                    <span className="font-semibold">Warehouse Service:</span>{" "}
                    {quote.IsWarehouseService ? "Yes" : "No"}
                  </p>
                  <p className="text-gray-600 mb-1">
                    <span className="font-semibold">Signature Required:</span>{" "}
                    {quote.SignatureRequiredAvailable ? "Yes" : "No"}
                  </p>
                  <div className="mt-2">
                    <p className="text-gray-600 font-semibold">
                      Cost Breakdown:
                    </p>
                    {quote.ServicePriceBreakdown.map((price, index) => (
                      <p key={index} className="text-gray-600 ml-2">
                        - {price.Description} ({price.Code}): £
                        {price.Cost.toFixed(2)}
                      </p>
                    ))}
                  </div>
                  <div className="mt-2">
                    <p className="text-gray-600 font-semibold">
                      Optional Extras:
                    </p>
                    {quote.OptionalExtras.map((extra, index) => (
                      <p key={index} className="text-gray-600 ml-2">
                        - {extra.Description} ({extra.Code}): £
                        {extra.Cost.toFixed(2)}
                      </p>
                    ))}
                  </div>
                  <p className="text-gray-800 font-bold mt-2">
                    Total Cost: £
                    {quote.TotalCost.TotalCostGrossWithCollection.toFixed(2)}
                  </p>
                  <button
                    onClick={() => handleServiceSelect(quote)}
                    className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    Select & Book
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p>No services available for this shipment.</p>
          )}
          <button
            onClick={() => setStep(2)}
            className="mt-4 px-6 py-3 bg-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-400"
          >
            Back
          </button>
        </div>
      )}

      {step === 4 && (
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-gray-800">
            Booking Confirmation
          </h2>
          <p className="text-green-600">Shipment booked successfully!</p>
          <p>Service: {selectedService?.ServiceName}</p>
          <p>Carrier: {selectedService?.CarrierName}</p>
          <p>
            Total Cost: £
            {selectedService?.TotalCost.TotalCostGrossWithCollection.toFixed(2)}
          </p>
        </div>
      )}
    </div>
  );
}
