import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../src/components/ui/select";
import type { ICountry } from "../../src/lib/models/Country";

interface Address {
  forename: string;
  surname: string;
  email: string;
  phone: string;
  companyName?: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  countryState: string;
  postcode: string;
  country: string; // Will store CountryCode
  countryId?: string;
}

interface AddressFormProps {
  onSubmit: (collection: Address, delivery: Address) => void;
}

const fetchCountries = async (): Promise<ICountry[]> => {
  const response = await fetch("/api/countries");
  if (!response.ok) {
    throw new Error("Failed to fetch countries");
  }
  return response.json();
};

export default function AddressForm({ onSubmit }: AddressFormProps) {
  const [collection, setCollection] = useState<Partial<Address>>({});
  const [delivery, setDelivery] = useState<Partial<Address>>({});
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const {
    data: countries = [],
    isError,
    error,
  } = useQuery({
    queryKey: ["countries"],
    queryFn: fetchCountries,
    staleTime: Number.POSITIVE_INFINITY,
    gcTime: Number.POSITIVE_INFINITY,
    retry: 3,
  });

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};

    if (!collection.forename)
      newErrors.collectionForename = "Forename is required";
    if (!collection.surname)
      newErrors.collectionSurname = "Surname is required";
    if (!collection.email) newErrors.collectionEmail = "Email is required";
    if (!collection.phone) newErrors.collectionPhone = "Phone is required";
    if (!collection.addressLine1)
      newErrors.collectionAddressLine1 = "Address Line 1 is required";
    if (!collection.city) newErrors.collectionCity = "City is required";
    if (!collection.countryState)
      newErrors.collectionCountryState = "Country/State is required";
    if (!collection.postcode)
      newErrors.collectionPostcode = "Postcode is required";
    if (!collection.country)
      newErrors.collectionCountry = "Country is required";

    if (!delivery.forename) newErrors.deliveryForename = "Forename is required";
    if (!delivery.surname) newErrors.deliverySurname = "Surname is required";
    if (!delivery.email) newErrors.deliveryEmail = "Email is required";
    if (!delivery.phone) newErrors.deliveryPhone = "Phone is required";
    if (!delivery.addressLine1)
      newErrors.deliveryAddressLine1 = "Address Line 1 is required";
    if (!delivery.city) newErrors.deliveryCity = "City is required";
    if (!delivery.countryState)
      newErrors.deliveryCountryState = "Country/State is required";
    if (!delivery.postcode) newErrors.deliveryPostcode = "Postcode is required";
    if (!delivery.country) newErrors.deliveryCountry = "Country is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(collection as Address, delivery as Address);
    }
  };

  const inputClass =
    "w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500";
  const errorClass = "text-red-500 text-sm mt-1";

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-800">
          Collection Address
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Forename *
            </label>
            <input
              type="text"
              className={inputClass}
              value={collection.forename || ""}
              onChange={(e) =>
                setCollection({ ...collection, forename: e.target.value })
              }
            />
            {errors.collectionForename && (
              <p className={errorClass}>{errors.collectionForename}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Surname *
            </label>
            <input
              type="text"
              className={inputClass}
              value={collection.surname || ""}
              onChange={(e) =>
                setCollection({ ...collection, surname: e.target.value })
              }
            />
            {errors.collectionSurname && (
              <p className={errorClass}>{errors.collectionSurname}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Email *
            </label>
            <input
              type="email"
              className={inputClass}
              value={collection.email || ""}
              onChange={(e) =>
                setCollection({ ...collection, email: e.target.value })
              }
            />
            {errors.collectionEmail && (
              <p className={errorClass}>{errors.collectionEmail}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Phone *
            </label>
            <input
              type="tel"
              className={inputClass}
              value={collection.phone || ""}
              onChange={(e) =>
                setCollection({ ...collection, phone: e.target.value })
              }
            />
            {errors.collectionPhone && (
              <p className={errorClass}>{errors.collectionPhone}</p>
            )}
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Company Name
            </label>
            <input
              type="text"
              className={inputClass}
              value={collection.companyName || ""}
              onChange={(e) =>
                setCollection({ ...collection, companyName: e.target.value })
              }
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Address Line 1 *
            </label>
            <input
              type="text"
              className={inputClass}
              value={collection.addressLine1 || ""}
              onChange={(e) =>
                setCollection({ ...collection, addressLine1: e.target.value })
              }
            />
            {errors.collectionAddressLine1 && (
              <p className={errorClass}>{errors.collectionAddressLine1}</p>
            )}
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Address Line 2
            </label>
            <input
              type="text"
              className={inputClass}
              value={collection.addressLine2 || ""}
              onChange={(e) =>
                setCollection({ ...collection, addressLine2: e.target.value })
              }
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              City *
            </label>
            <input
              type="text"
              className={inputClass}
              value={collection.city || ""}
              onChange={(e) =>
                setCollection({ ...collection, city: e.target.value })
              }
            />
            {errors.collectionCity && (
              <p className={errorClass}>{errors.collectionCity}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Country/State *
            </label>
            <input
              type="text"
              className={inputClass}
              value={collection.countryState || ""}
              onChange={(e) =>
                setCollection({ ...collection, countryState: e.target.value })
              }
            />
            {errors.collectionCountryState && (
              <p className={errorClass}>{errors.collectionCountryState}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Postcode *
            </label>
            <input
              type="text"
              className={inputClass}
              value={collection.postcode || ""}
              onChange={(e) =>
                setCollection({ ...collection, postcode: e.target.value })
              }
            />
            {errors.collectionPostcode && (
              <p className={errorClass}>{errors.collectionPostcode}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Country *
            </label>
            <Select
              value={collection.countryId || ""}
              onValueChange={(value) => {
                const selectedCountry = countries.find(
                  (country) => country.CountryID.toString() === value
                );
                setCollection({
                  ...collection,
                  countryId: value,
                  country: selectedCountry?.CountryCode || "", // Use CountryCode instead of Title
                });
              }}
              disabled={isError}
            >
              <SelectTrigger className={inputClass}>
                <SelectValue placeholder="Select a country" />
              </SelectTrigger>
              <SelectContent>
                {countries.map((country) => (
                  <SelectItem
                    key={country.CountryID}
                    value={country.CountryID.toString()}
                  >
                    {country.Title} ({country.CountryCode})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.collectionCountry && (
              <p className={errorClass}>{errors.collectionCountry}</p>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-800">
          Delivery Address
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Forename *
            </label>
            <input
              type="text"
              className={inputClass}
              value={delivery.forename || ""}
              onChange={(e) =>
                setDelivery({ ...delivery, forename: e.target.value })
              }
            />
            {errors.deliveryForename && (
              <p className={errorClass}>{errors.deliveryForename}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Surname *
            </label>
            <input
              type="text"
              className={inputClass}
              value={delivery.surname || ""}
              onChange={(e) =>
                setDelivery({ ...delivery, surname: e.target.value })
              }
            />
            {errors.deliverySurname && (
              <p className={errorClass}>{errors.deliverySurname}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Email *
            </label>
            <input
              type="email"
              className={inputClass}
              value={delivery.email || ""}
              onChange={(e) =>
                setDelivery({ ...delivery, email: e.target.value })
              }
            />
            {errors.deliveryEmail && (
              <p className={errorClass}>{errors.deliveryEmail}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Phone *
            </label>
            <input
              type="tel"
              className={inputClass}
              value={delivery.phone || ""}
              onChange={(e) =>
                setDelivery({ ...delivery, phone: e.target.value })
              }
            />
            {errors.deliveryPhone && (
              <p className={errorClass}>{errors.deliveryPhone}</p>
            )}
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Company Name
            </label>
            <input
              type="text"
              className={inputClass}
              value={delivery.companyName || ""}
              onChange={(e) =>
                setDelivery({ ...delivery, companyName: e.target.value })
              }
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Address Line 1 *
            </label>
            <input
              type="text"
              className={inputClass}
              value={delivery.addressLine1 || ""}
              onChange={(e) =>
                setDelivery({ ...delivery, addressLine1: e.target.value })
              }
            />
            {errors.deliveryAddressLine1 && (
              <p className={errorClass}>{errors.deliveryAddressLine1}</p>
            )}
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700">
              Address Line 2
            </label>
            <input
              type="text"
              className={inputClass}
              value={delivery.addressLine2 || ""}
              onChange={(e) =>
                setDelivery({ ...delivery, addressLine2: e.target.value })
              }
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              City *
            </label>
            <input
              type="text"
              className={inputClass}
              value={delivery.city || ""}
              onChange={(e) =>
                setDelivery({ ...delivery, city: e.target.value })
              }
            />
            {errors.deliveryCity && (
              <p className={errorClass}>{errors.deliveryCity}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Country/State *
            </label>
            <input
              type="text"
              className={inputClass}
              value={delivery.countryState || ""}
              onChange={(e) =>
                setDelivery({ ...delivery, countryState: e.target.value })
              }
            />
            {errors.deliveryCountryState && (
              <p className={errorClass}>{errors.deliveryCountryState}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Postcode *
            </label>
            <input
              type="text"
              className={inputClass}
              value={delivery.postcode || ""}
              onChange={(e) =>
                setDelivery({ ...delivery, postcode: e.target.value })
              }
            />
            {errors.deliveryPostcode && (
              <p className={errorClass}>{errors.deliveryPostcode}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Country *
            </label>
            <Select
              value={delivery.countryId || ""}
              onValueChange={(value) => {
                const selectedCountry = countries.find(
                  (country) => country.CountryID.toString() === value
                );
                setDelivery({
                  ...delivery,
                  countryId: value,
                  country: selectedCountry?.CountryCode || "", // Use CountryCode instead of Title
                });
              }}
              disabled={isError}
            >
              <SelectTrigger className={inputClass}>
                <SelectValue placeholder="Select a country" />
              </SelectTrigger>
              <SelectContent>
                {countries.map((country) => (
                  <SelectItem
                    key={country.CountryID}
                    value={country.CountryID.toString()}
                  >
                    {country.Title} ({country.CountryCode})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.deliveryCountry && (
              <p className={errorClass}>{errors.deliveryCountry}</p>
            )}
          </div>
        </div>
      </div>

      <button
        type="submit"
        className="w-full md:w-auto px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
      >
        Next: Package Details
      </button>
    </form>
  );
}
