import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../src/components/ui/select";
import type { ICountry } from "../../src/lib/models/Country";

interface PackageItem {
  description: string;
  commodityCode: string;
  countryOfOrigin: string; // Will store CountryCode
  countryOfOriginId?: string;
  quantity: number;
  valuePerItem: number;
  weightPerItem: number;
  length: number;
  width: number;
  height: number;
}

interface PackageDetailsFormProps {
  onSubmit: (
    items: PackageItem[],
    reason: string,
    collectionDate: string,
    readyFrom: string
  ) => void;
  onBack: () => void;
}

const fetchCountries = async (): Promise<ICountry[]> => {
  const response = await fetch("/api/countries");
  if (!response.ok) {
    throw new Error("Failed to fetch countries");
  }
  return response.json();
};

export default function PackageDetailsForm({
  onSubmit,
  onBack,
}: PackageDetailsFormProps) {
  const [items, setItems] = useState<PackageItem[]>([]);
  const [newItem, setNewItem] = useState<Partial<PackageItem>>({
    quantity: 1,
    valuePerItem: 0,
    weightPerItem: 0,
    length: 0,
    width: 0,
    height: 0,
  });
  const [reason, setReason] = useState<string>("");
  const [collectionDate, setCollectionDate] = useState<string>("");
  const [readyFrom, setReadyFrom] = useState<string>("");
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const {
    data: countries = [],
    isError,
    error,
  } = useQuery({
    queryKey: ["countries"],
    queryFn: fetchCountries,
    staleTime: Number.POSITIVE_INFINITY,
    gcTime: Number.POSITIVE_INFINITY,
    retry: 3,
  });

  const validateItem = () => {
    const newErrors: { [key: string]: string } = {};

    if (!newItem.description) newErrors.description = "Description is required";
    if (!newItem.commodityCode)
      newErrors.commodityCode = "Commodity Code is required";
    if (!newItem.countryOfOrigin)
      newErrors.countryOfOrigin = "Country of Origin is required";
    if (!newItem.quantity || newItem.quantity <= 0)
      newErrors.quantity = "Quantity must be greater than 0";
    if (!newItem.valuePerItem || newItem.valuePerItem <= 0)
      newErrors.valuePerItem = "Value must be greater than 0";
    if (!newItem.weightPerItem || newItem.weightPerItem <= 0)
      newErrors.weightPerItem = "Weight must be greater than 0";
    if (!newItem.length || newItem.length <= 0)
      newErrors.length = "Length must be greater than 0";
    if (!newItem.width || newItem.width <= 0)
      newErrors.width = "Width must be greater than 0";
    if (!newItem.height || newItem.height <= 0)
      newErrors.height = "Height must be greater than 0";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};

    if (!reason) newErrors.reason = "Reason for shipment is required";
    if (!collectionDate)
      newErrors.collectionDate = "Collection date is required";
    if (!readyFrom) newErrors.readyFrom = "Ready from time is required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAddItem = () => {
    if (validateItem()) {
      const updatedItems = [...items, newItem as PackageItem];
      setItems(updatedItems);
      setNewItem({
        quantity: 1,
        valuePerItem: 0,
        weightPerItem: 0,
        length: 0,
        width: 0,
        height: 0,
      });
      setErrors({});
    }
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
    setErrors((prev) => {
      const newErrors = { ...prev };
      delete newErrors.weightMatch;
      return newErrors;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(items, reason, collectionDate, readyFrom);
    }
  };

  const inputClass =
    "w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500";
  const errorClass = "text-red-500 text-sm mt-1";

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-gray-800">Package Details</h2>
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Reason for Shipment *
          </label>
          <select
            className={inputClass}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
          >
            <option value="">Please specify</option>
            <option value="GIFT">Gift</option>
            <option value="INTERCOMPANY_DATA">Intercompany Data</option>
            <option value="SALES">Sales</option>
            <option value="SAMPLE">Sample</option>
            <option value="REPAIR">Repair</option>
            <option value="RETURN">Return</option>
            <option value="OTHER">Other</option>
          </select>
          {errors.reason && <p className={errorClass}>{errors.reason}</p>}
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-700">
            Collection Details
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Collection Date *
              </label>
              <input
                type="date"
                className={inputClass}
                value={collectionDate}
                onChange={(e) => setCollectionDate(e.target.value)}
              />
              {errors.collectionDate && (
                <p className={errorClass}>{errors.collectionDate}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Ready From Time *
              </label>
              <input
                type="time"
                className={inputClass}
                value={readyFrom}
                onChange={(e) => setReadyFrom(e.target.value)}
              />
              {errors.readyFrom && (
                <p className={errorClass}>{errors.readyFrom}</p>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-700">Add Item</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Description *
              </label>
              <input
                type="text"
                className={inputClass}
                value={newItem.description || ""}
                onChange={(e) =>
                  setNewItem({ ...newItem, description: e.target.value })
                }
              />
              {errors.description && (
                <p className={errorClass}>{errors.description}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Commodity Code *
              </label>
              <input
                type="text"
                className={inputClass}
                value={newItem.commodityCode || ""}
                onChange={(e) =>
                  setNewItem({ ...newItem, commodityCode: e.target.value })
                }
              />
              {errors.commodityCode && (
                <p className={errorClass}>{errors.commodityCode}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Country of Origin *
              </label>
              <Select
                value={newItem.countryOfOriginId || ""}
                onValueChange={(value) => {
                  const selectedCountry = countries.find(
                    (country) => country.CountryID.toString() === value
                  );
                  setNewItem({
                    ...newItem,
                    countryOfOriginId: value,
                    countryOfOrigin: selectedCountry?.CountryCode || "", // Use CountryCode
                  });
                }}
                disabled={isError}
              >
                <SelectTrigger className={inputClass}>
                  <SelectValue placeholder="Select a country" />
                </SelectTrigger>
                <SelectContent>
                  {countries.map((country) => (
                    <SelectItem
                      key={country.CountryID}
                      value={country.CountryID.toString()}
                    >
                      {country.Title} ({country.CountryCode})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.countryOfOrigin && (
                <p className={errorClass}>{errors.countryOfOrigin}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Quantity *
              </label>
              <input
                type="number"
                className={inputClass}
                value={newItem.quantity || 1}
                onChange={(e) =>
                  setNewItem({ ...newItem, quantity: parseInt(e.target.value) })
                }
              />
              {errors.quantity && (
                <p className={errorClass}>{errors.quantity}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Value per Item (£) *
              </label>
              <input
                type="number"
                className={inputClass}
                value={newItem.valuePerItem || 0}
                onChange={(e) =>
                  setNewItem({
                    ...newItem,
                    valuePerItem: parseFloat(e.target.value),
                  })
                }
              />
              {errors.valuePerItem && (
                <p className={errorClass}>{errors.valuePerItem}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Weight per Item (kg) *
              </label>
              <input
                type="number"
                className={inputClass}
                value={newItem.weightPerItem || 0}
                onChange={(e) =>
                  setNewItem({
                    ...newItem,
                    weightPerItem: parseFloat(e.target.value),
                  })
                }
              />
              {errors.weightPerItem && (
                <p className={errorClass}>{errors.weightPerItem}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Length (cm) *
              </label>
              <input
                type="number"
                className={inputClass}
                value={newItem.length || 0}
                onChange={(e) =>
                  setNewItem({ ...newItem, length: parseFloat(e.target.value) })
                }
              />
              {errors.length && <p className={errorClass}>{errors.length}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Width (cm) *
              </label>
              <input
                type="number"
                className={inputClass}
                value={newItem.width || 0}
                onChange={(e) =>
                  setNewItem({ ...newItem, width: parseFloat(e.target.value) })
                }
              />
              {errors.width && <p className={errorClass}>{errors.width}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Height (cm) *
              </label>
              <input
                type="number"
                className={inputClass}
                value={newItem.height || 0}
                onChange={(e) =>
                  setNewItem({ ...newItem, height: parseFloat(e.target.value) })
                }
              />
              {errors.height && <p className={errorClass}>{errors.height}</p>}
            </div>
          </div>
          <button
            type="button"
            onClick={handleAddItem}
            className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
          >
            Add Item
          </button>
        </div>

        {items.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-lg font-medium text-gray-700">Items</h3>
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-2 text-left">Description</th>
                  <th className="p-2 text-left">Commodity Code</th>
                  <th className="p-2 text-left">Country of Origin</th>
                  <th className="p-2 text-left">Quantity</th>
                  <th className="p-2 text-left">Value (£)</th>
                  <th className="p-2 text-left">Weight (kg)</th>
                  <th className="p-2 text-left">Length (cm)</th>
                  <th className="p-2 text-left">Width (cm)</th>
                  <th className="p-2 text-left">Height (cm)</th>
                  <th className="p-2 text-left"></th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => (
                  <tr key={index} className="border-b">
                    <td className="p-2">{item.description}</td>
                    <td className="p-2">{item.commodityCode}</td>
                    <td className="p-2">{item.countryOfOrigin}</td>
                    <td className="p-2">{item.quantity}</td>
                    <td className="p-2">{item.valuePerItem}</td>
                    <td className="p-2">{item.weightPerItem}</td>
                    <td className="p-2">{item.length}</td>
                    <td className="p-2">{item.width}</td>
                    <td className="p-2">{item.height}</td>
                    <td className="p-2">
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(index)}
                        className="text-red-500 hover:text-red-700"
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="flex space-x-4">
        <button
          type="button"
          onClick={onBack}
          className="px-6 py-3 bg-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-400 transition-colors"
        >
          Back
        </button>
        <button
          type="submit"
          className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
        >
          Next: Summary
        </button>
      </div>
    </form>
  );
}
